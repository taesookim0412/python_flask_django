from django.apps import AppConfig


class StringsConfig(AppConfig):
    name = 'strings'
