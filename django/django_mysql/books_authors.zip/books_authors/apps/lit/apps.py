from django.apps import AppConfig


class LitConfig(AppConfig):
    name = 'lit'
