from django.apps import AppConfig


class WishappConfig(AppConfig):
    name = 'wishapp'
